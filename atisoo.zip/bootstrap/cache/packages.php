<?php return array (
  'evryn/laravel-toman' => 
  array (
    'providers' => 
    array (
      0 => 'Evryn\\LaravelToman\\LaravelTomanServiceProvider',
    ),
    'aliases' => 
    array (
      'Payment' => 'Evryn\\LaravelToman\\Facades\\Payment',
    ),
  ),
  'ghasedak/laravel' => 
  array (
    'providers' => 
    array (
      0 => 'Ghasedak\\Laravel\\GhasedakServiceProvider',
    ),
    'aliases' => 
    array (
      'Ghasedak' => 'Ghasedak\\Laravel\\GhasedakFacade',
    ),
  ),
  'laravel/sanctum' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Sanctum\\SanctumServiceProvider',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'nesbot/carbon' => 
  array (
    'providers' => 
    array (
      0 => 'Carbon\\Laravel\\ServiceProvider',
    ),
  ),
  'nunomaduro/termwind' => 
  array (
    'providers' => 
    array (
      0 => 'Termwind\\Laravel\\TermwindServiceProvider',
    ),
  ),
);