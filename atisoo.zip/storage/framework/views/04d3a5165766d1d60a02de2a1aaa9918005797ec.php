
<?php $__env->startSection('content'); ?>
<table class="table table-striped table-advance table-hover">
    <thead>
    <tr>
        <td>نام</td>
        <td>حذف</td>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $device; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($item->name1); ?></td>
            <form action="<?php echo e(route('byForYouDelete',['id'=>$item->id])); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('delete'); ?>
                <td>
                    <button class="btn btn-danger btn-xs"><i class="icon-trash "></i></button>
                </td>
            </form>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\i\Documents\laravel\resources\views/admin/byForYou/list.blade.php ENDPATH**/ ?>