
<?php $__env->startSection('keys'); ?><?php echo e($info->resetDeviceKey); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>
    ریست رمز دستگاه
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <a href="/">
        <div class="home"><i class="fa fa-home"></i><br>صفحه اصلی </div>
    </a>
    
    <section style="margin-top: 120px" class="section1">
        <img src="<?php echo e($info->logo); ?>" class="logo-img" alt="موردی یافت نشد"><br>
        <h1>ریست رمز DVR ,NVR</h1><br>
    </section>
    <section class="by-for-you-contaoner">
        <ul>
            <?php if($device != 'null'): ?>
                <?php $__currentLoopData = $device; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="flash-cont-by-for-you">
                        <div class="flash-dis-cont-by-for-you">
                            <div> آیدی سایت : <span><?php echo e($item->id2); ?></span></div>
                            <div><br>
                                توضیحات :
                                <br>
                                <audio src="<?php echo e($item->mp3); ?>" controls></audio>
                            </div>
                            <div><br>
                                توضیحات  متنی:
                                <br>
                                <pre>
                                    <?php echo e($item->description); ?>

                                </pre>
                            </div><br>
                            <div><br>
                                 نرم افزار ها :
                                <br>
                                <?php
                                    $apps =  json_decode($item->apps)
                                ?>
                                <?php $__currentLoopData = $apps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a class="apps-link" href="<?php echo e($value); ?>">نرم افزار <?php echo e($key+1); ?></a><br>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                        <div class="flash-img-cont">
                            <div class="slider">
                                <?php
                                    $imags = json_decode($item->imags);
                                ?>
                                <?php $__currentLoopData = $imags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="img-magnifier-container">
                                    <img class="myimage" src="<?php echo e($img); ?>" alt="موردی یافت نشد" />
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <div class="next fa fa-right-long"></div>
                                <div class="prev fa fa-left-long"></div>
                            </div>
                            <div><br>
                                فیلم اموزشی :
                                <br>
                                <video src="<?php echo e($item->vedio); ?>" controls></video>
                            </div>
                        </div>
                       
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <?php if(count($device) == 0): ?>
                موردی در حال حال حاضر وجود ندارد
            <?php endif; ?>
        </ul>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        $('.dropdao-btn').eq(0).css('box-shadow', '0px 8px 5px rgb(33 135 0)');
    </script>
<?php $__env->stopSection(); ?>
  
<?php echo $__env->make('flash.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\i\Desktop\flash\resources\views\flash\resetDevice.blade.php ENDPATH**/ ?>