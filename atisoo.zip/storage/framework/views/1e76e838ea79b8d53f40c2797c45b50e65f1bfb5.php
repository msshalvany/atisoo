<?php $__env->startSection('keys'); ?>
    <?php echo e($info->indexKey); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>
    168716
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <style>
        .byForYou {
            display: none
        }

        .abute {
            display: none
        }

        .dropdao-btn-container {
            display: none
        }

        .searchViwe {
            display: none
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="section1">
        <img src="<?php echo e($info->logo); ?>" class="logo-img" alt="موردی یافت نشد"><br>
        <h1>خدمات آنلاین دوربین مداربسته و dvr , nvr</h1><br>
        
        <div class="count-user-file">
            <div class="count-user">
                <div class="icon"><i class="fa fa-user"></i></div>
                <div class="count"><?php echo e($userCount); ?></div>
                <p>تعداد همکارانی که ثبت نام کرده اند
                     </p>
            </div>
            
        </div>
        <div class="circle-menue">
            <a href="/resetDe">ریست پسورد DVR , NVR</a>
            <a href="/resetCa">ریست پسورد دوربین ip</a>
            <a href="/searchViwe">جستجوی فایل فلش</a>
            <a class="updateBtn" href="">جستجوی فایل آپدیت</a>
            <a href="/byForYou">خرید فایل فلش  از شما</a>
            <a class="updateBtnBy" href="">خرید  فایل آپدیت از شما</a>
            <a href="/abute">درباره ما</a>
        </div>
    </section>

    
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script !src="">
        $('.updateBtn').click(function(e) {
            e.preventDefault();
            alertSucsses('در حال توسعه به زودی فعال میشود')
        });
        $('.updateBtnBy').click(function(e) {
            e.preventDefault();
            alertSucsses('در حال توسعه به زودی فعال میشود')
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('flash.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\mobotop\Desktop\laravel\resources\views/flash/index.blade.php ENDPATH**/ ?>