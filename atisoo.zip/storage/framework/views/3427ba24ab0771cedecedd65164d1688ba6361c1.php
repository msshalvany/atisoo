<?php $__env->startSection('title'); ?>
    ثبت نام
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<style>
    *{
        color: black
    }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="forms-start">
        <a href="/">
            <div class="home"><i style="color: white" class="fa fa-home"></i><br>صفحه اصلی </div>
        </a>
        <div class="eroore">شما خطا دارید</div>
        <div class="sucses">بلیت شما رزرو شد</div>
        <form class="form-1" action="">
            <label for="usrename">شماره همراه خود را وارد کنید :</label>
            <input type="text" id="phon" name="phon" placeholder="مثال : 09131572450" />
            <input type="submit" value="ارسال" />
        </form>
        <form class="form-2" action="">
            <label for="code">کد SMS شده را وارد کنید:</label>
            <input type="text" id="code" name="code" />
            <input type="submit" value="ارسال" />
        </form>
        <form class="form-3" action="">
            <label for="time"> یک رمز عبور برای خود انتخاب کنید :</label>
            <input type="text" id="password" name="password" />
            <input id="send" type="submit" value="ارسال" />
        </form>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $('.login-regester').css('box-shadow', '0px 8px 5px rgb(122 122 122)');
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('flash.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/atisooir/lara/resources/views/flash/register.blade.php ENDPATH**/ ?>