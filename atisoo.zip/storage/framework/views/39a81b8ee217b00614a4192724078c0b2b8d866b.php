
<?php $__env->startSection('title'); ?>
    چت با مدریت
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <style>
        .chat-icon {
            display: none;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <a href="/">
        <div class="home"><i class="fa fa-home"></i><br>صفحه اصلی </div>
    </a>
    <div class="texts-container">
        <?php $__currentLoopData = $messegs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($item->user_id == 'maneger'): ?>
                <div class="maneger-text-con" id="<?php echo e($item->id); ?>">
                    <img src="flash/img/maneger.png" alt="">
                    <div class="maneger-text parent-image">
                        <?php if($item->file != null): ?>
                            <a class="downloade-file-chat" href="/<?php echo e($item->file); ?>" controls><i class="fa fa-file"></i></a><br>
                        <?php endif; ?>
                        <?php if($item->image != null): ?>
                            <img width="100%" class="pic" src="<?php echo e($item->image); ?>" alt="">
                        <?php endif; ?>
                        <?php echo e($item->text); ?>

                    </div>
                </div>
            <?php else: ?>
                <div class="user-text-con"  id="<?php echo e($item->id); ?>">
                    <img class="user-image" src="<?php echo e($user->image); ?>"alt="">
                    <div class="user-text">
                        <?php if($item->file != null): ?>
                            <a class="downloade-file-chat" href="/<?php echo e($item->file); ?>" controls><i class="fa fa-file"></i></a><br>
                        <?php endif; ?>
                        <?php if($item->image != null): ?>
                            <img width="100%" class="pic" src="<?php echo e($item->image); ?>" alt="">
                        <?php endif; ?>
                        <?php echo e($item->text); ?>

                    </div>
                </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <button class="chateOther" onclick="chateOther()"><i class="fa fa-arrow-up"></i></button>
    </div>
    <div class="chat-form-container">
        <form class="chat-inputs" method="POST" action="/reciveData" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <button class="send-chat"><i class="fa fa-paper-plane"></i></button>
            <textarea name="text" id="" placeholder="پیام خود را تایپ کنید ......"></textarea>
            <label class="label">
                <input id="file-uplode" name="file" type="file" />
                <span><i class="fa fa-image"></i></span>
            </label>
            <?php
                $chat_id = App\Models\chate::where('user_id', session()->get('user'))->get()[0]->id;
            ?>
            <input type="hidden" name="chat_id" , value="<?php echo e($chat_id); ?>">
        </form>
        <button id="btnStart" class="send-voice"><i class="fa fa-microphone"></i></button>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $('.login-regester').css('box-shadow', '0px 8px 5px rgb(122 122 122)');
    </script>
    <?php if(session('completeError')): ?>
        <script !src="">
            alertEore('اطاتعتن نامناسب تکمیل شده')
        </script>
    <?php endif; ?>
    <script>
        var chateOtherCounter = 1;
  function chateOther() {
    $.ajax({
      type: "post",
      url: `/chateOther/${chateOtherCounter}`,
      processData: false,
      contentType: false,
      success: function (response) {
        response.forEach((data) => {
          var user_id = data.id
          var style_user = ''
          var user_image = ""
          if (data.user_id == 'maneger') {
            user_id = "maneger-text-con"
            style_user = 'maneger-text'
            user_image = "flash/img/maneger.png"
          }else{
            user_id = "user-text-con"
            style_user = 'user-text'
            user_image = $('.user-image').attr('src');
          }
          if (data.image != null) {
            $(".texts-container").append(`
                  <div class="${user_id}" id="${data.id}">
                  <img src="${user_image}"alt="">
                    <div class="${style_user}">
                      <img style="width: 100%" src="${data.image}" controls />
                      ${data.text ? data.text : ""}
                    </div>
                  </div>  
                  `);
          } else if (data.file != null) {
            $(".texts-container").append(`
                  <div class="${user_id}" id="${data.id}"> 
                  <img src="${user_image}"alt="">
                    <div class="${style_user}">
                      <a class="downloade-file-chat" href="${
                        data.file
                      }" controls ><i class="fa fa-file"></i></a><br><br>
                      ${data.text ? data.text : ""}
                    </div>
                  </div>  
                     <img src="flash/img/maneger.png"alt="">
               `);
          } else {
            $(".texts-container").append(`
                  <div class="${user_id}" id="${data.id}"> 
                  <img src="${user_image}"alt="">
                    <div class="${style_user}">
                    ${data.text}
                    </div>
                  </div>  
                  `);
          }
        });   
        $('.chateOther').remove();
        $(".texts-container").append(`<button class="chateOther" onclick="chateOther()"><i class="fa fa-arrow-up"></i></button>`)
        chateOtherCounter++
      },
    });
  }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('flash.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\i\Downloads\idea\resources\views/flash/chat.blade.php ENDPATH**/ ?>