
<?php $__env->startSection('title'); ?>
    ثبت نام
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <style>
        .form-complete {
            top: 50%;
            margin-top: -200px !important;
            height: 300px !important;
        }

        /* file upload button */
        input[type="file"]::file-selector-button {
            border-radius: 4px;
            padding: 0 16px;
            height: 40px;
            cursor: pointer;
            background-color: #0059FF;
            color: white;
            border: 1px solid #0059FF;
            box-shadow: 0px 1px 0px rgba(0, 0, 0, 0.05);
            margin-right: 16px;
            transition: background-color 200ms;
        }

        /* file upload button hover state */
        input[type="file"]::file-selector-button:hover {
            background-color: transparent;
            color: #0059FF;
        }

        /* file upload button active state */
        input[type="file"]::file-selector-button:active {
            background-color: #e5e7eb;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="forms-start">
        <a href="/">
            <div class="home"><i style="color: white" class="fa fa-home"></i><br>صفحه اصلی </div>
        </a>
        <form class="form-complete" action="<?php echo e(route('completeInfo', ['id' => session()->get('user')])); ?>" method="POST"
            enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <label for="usrename">نام خود به انگلیسی یا فارسی بنویسید</label>
            <input type="text" id="name" name="name" placeholder="فقط شامل حروف فارسی یا انگلیسی" />
            <label for="usrename">یک عکس برای پروفایل خود اپلود کنید:</label>
            <input type="file" id="pic" name="pic" />
            <input type="submit" value="ارسال" />
        </form>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $('.login-regester').css('box-shadow', '0px 8px 5px rgb(122 122 122)');
    </script>
    <?php if(session('completeError')): ?>
        <script !src="">
            alertEore('اطاتعتن نامناسب تکمیل شده')
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('flash.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\i\Downloads\idea\resources\views/flash/completeInfo.blade.php ENDPATH**/ ?>