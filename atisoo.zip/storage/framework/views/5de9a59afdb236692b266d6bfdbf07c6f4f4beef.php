<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Mosaddek">
    <meta name="keyword" content="FlatLab, Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
    <link rel="shortcut icon" href="img/favicon.html">

    <title>atisoo Admin</title>
    <link href="/admin/css/bootstrap.min.css" rel="stylesheet">
    <link href="/admin/css/bootstrap-reset.css" rel="stylesheet">
    <link href="/admin/assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link href="/admin/css/style.css" rel="stylesheet">
    <link href="/admin/css/style-responsive.css" rel="stylesheet">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.1/css/font-awesome.min.css" rel="stylesheet" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <script src="/admin/js/jquery.js"></script>
    <script src="/flash/js/function.js"></script>
    <style>
        .chateOther {
            width: 52px;
            align-self: center;
            border-radius: 12px;
            border: none;
            background: #dfdfdf;
            padding: 6px;
            font-size: 21px
        }
    </style>
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 tooltipss and media queries -->
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->
</head>

<body>
    <div class="user" id="<?php echo e($user->id); ?>"></div>
    <div class="chate_id" id="<?php echo e($chate_id); ?>"></div>
    <a href="/dashbord/chatlist">
        <div class="chat-back"><i class="fa fa-backward"></i><br></div>
    </a>
    <div class="texts-container">
        <?php $__currentLoopData = $messegs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($item->user_id == 'maneger'): ?>
                <div class="maneger-text-con" id="<?php echo e($item->id); ?>">
                    <img src="/flash/img/maneger.png" alt="">
                    <div class="maneger-text parent-image">
                        <?php if($item->file != null): ?>
                            <a class="downloade-file-chat" href="/<?php echo e($item->file); ?>" controls><i class="fa fa-file"></i></a><br>
                        <?php endif; ?>
                        <?php if($item->image != ''): ?>
                            <img width="100%" class="pic" src="/<?php echo e($item->image); ?>" alt="">
                        <?php endif; ?>
                        <?php echo e($item->text); ?>

                    </div>
                </div>
            <?php else: ?>
                <div class="user-text-con" id="<?php echo e($item->id); ?>">
                    <img class="user-image" src="/<?php echo e($user->image); ?>"alt="">
                    <div class="user-text">
                        <?php if($item->file != null): ?>
                            <a class="downloade-file-chat" href="/<?php echo e($item->file); ?>" controls><i
                                    class="fa fa-file"></i></a><br>
                        <?php endif; ?>
                        <?php if($item->image != null): ?>
                            <img width="100%" class="pic" src="/<?php echo e($item->image); ?>" alt="">
                        <?php endif; ?>
                        <?php echo e($item->text); ?>

                    </div>
                </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <button class="chateOther" onclick="chateOther()"><i class="fa fa-arrow-up"></i></button>
    </div>
    <div class="chat-form-container">
        <form class="chat-inputs" method="POST" action="<?php echo e(route('reciveDataAdmin')); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <button class="send-chat"><i class="fa fa-paper-plane"></i></button>
            <textarea name="text" placeholder="پیام خود را تایپ کنید ......"></textarea>
            <label class="label">
                <input id="file-uplode" name="file" type="file" />
                <span><i class="fa fa-image"></i></span>
            </label>
            <input type="hidden" name="chate_id" value="<?php echo e($chate_id); ?>">
        </form>
        <button id="btnStart" class="send-voice"><i class="fa fa-microphone"></i></button>
    </div>
</body>
<script>
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    function seeAdmin() {
        var chate_id = $('.chate_id').attr('id');
        var last_Messege = $('.texts-container').children().eq(0).attr('id');
        $.ajax({
            type: "get",
            url: `/lastSeenAdmin/${last_Messege}/${chate_id}`,
            processData: false,
            contentType: false,
            success: function(response) {
                console.log(response);
            }
        });
    }
    $(window).load(function(e) {
        seeAdmin()
    });


    //==================chat================
    $(".image-loder").click(function(e) {
        e.preventDefault();
        var src = $(e.target)
            .parents()
            .find(".parent-image")
            .find(".image-loder")
            .attr("id");
        $(e.target)
            .parents()
            .find(".parent-image")
            .prepend(`<img width="100%" src='${src}'>`);
        $(e.target).parents().find(".image-loder").remove();
    });
    $(".chat-inputs").submit(function(e) {
        e.preventDefault();
        var formValues = new FormData();
        $.ajax({
            url: $(this).attr("action"),
            type: $(this).attr("method"),
            dataType: "JSON",
            data: new FormData(this),
            processData: false,
            contentType: false,
            success: function(data) {
                if (data == 0) {
                    alertEore("این فرمت پشتیبانی نمی شود");
                } else if (data.type == "pic") {
                    $(".texts-container").prepend(`
                  <div class="maneger-text-con" id="${data.masssege.id}">
                  <img src="/flash/img/maneger.png"alt="">
                    <div class="maneger-text">
                      <img style="width: 100%" src="/${data.path}" controls />
                      ${data.text ? data.text : ''}
                    </div>
                  </div>  
                  `);
                } else if (data.type == "file") {
                    $(".texts-container").prepend(`
                  <div class="maneger-text-con" id="${data.masssege.id}"> 
                  <img src="/flash/img/maneger.png"alt="">
                    <div class="maneger-text">
                      <a class="downloade-file-chat" href="/${data.path}" controls ><i class="fa fa-file"></i></a><br><br>
                      ${data.text ? data.text : ''}
                    </div>
                  </div>  
                  `);
                } else if (data.type == "text") {
                    $(".texts-container").prepend(`
                  <div class="maneger-text-con" id="${data.masssege.id}"> 
                  <img src="/flash/img/maneger.png"alt="">
                    <div class="maneger-text">
                      ${data.text}
                    </div>
                  </div>  
                  `);
                }
                $(".chat-inputs").trigger("reset");
                seeAdmin()
            },
        });
    });

    // =============voice=============
    // =============voice=============
    // =============voice=============
    // =============voice=============
    // =============voice=============
    $(".send-voice").click(function(e) {
        e.preventDefault();
        let chunks = [];
        var statusRecord = $(".send-voice").attr("id");
        if (statusRecord == "btnStart") {
            $(".send-voice").attr("id", "btnStop");
            $(".send-voice i").removeClass();
            $('.send-voice i').attr("class", "fa fa-stop");
        } else {
            $(".send-voice").attr("id", "btnStart");
            $('.send-voice i').attr("class", "fa fa-microphone");
        }
    });
    setInterval(() => {
        var lastMessege = $(".texts-container").children().eq(0).attr("id");
        var image = $('.user-text-con').children().find('img').attr("src")
        $.ajax({
            url: `/checkSendChat`,
            type: "POST",
            dataType: "JSON",
            data: {
                id: lastMessege,
                user: $(".user").attr("id")
            },
            success: function(data) {
                if (data != 0) {
                    if (data.image != null) {
                        $(".texts-container").prepend(`
                            <div class="user-text-con" id="${data.id}">
                            <img src="${image}"alt="">
                                <div class="user-text">
                                <img style="width: 100%" src="/${data.image}" controls />
                                ${data.text ? data.text : ''}
                                </div>
                            </div>  
                        `);
                        $('.texts-container').scrollTop(200);

                    } else if (data.file != null) {
                        $(".texts-container").prepend(`
                        <div class="user-text-con" id="${data.id}"> 
                        <img src="${image}"alt="">
                            <div class="user-text">
                            <a class="/${data.user.image}" href="/${data.file}" controls ><i class="fa fa-file"></i></a><br><br>
                            ${data.text ? data.text : ''}
                            </div>
                        </div>  
                            <img src="/flash/img/maneger.png"alt="">
                        `);
                        $('.texts-container').scrollTop(200);

                    } else {
                        $(".texts-container").prepend(`
                        <div class="user-text-con" id="${data.id}"> 
                        <img src="${image}"alt="">
                            <div class="user-text">
                            ${data.text}
                            </div>
                        </div>  
                        `);
                    }
                    $('.texts-container').scrollTop(200);
                    seeAdmin()
                }
            },
        });
    }, 2000);
    var chateOtherCounter = 1;

    function chateOther() {
        $.ajax({
            type: "post",
            url: `/chateOther/${chateOtherCounter}`,
            processData: false,
            contentType: false,
            success: function(response) {
                response.forEach((data) => {
                    var user_id = data.id
                    var style_user = ''
                    var user_image = ""
                    if (data.user_id == 'maneger') {
                        user_id = "maneger-text-con"
                        style_user = 'maneger-text'
                        user_image = "/flash/img/maneger.png"
                    } else {
                        user_id = "user-text-con"
                        style_user = 'user-text'
                        user_image = $('.user-image').attr('src');
                    }
                    if (data.image != null) {
                        $(".texts-container").append(`
                  <div class="${user_id}" id="${data.id}">
                  <img src="${user_image}"alt="">
                    <div class="${style_user}">
                      <img style="width: 100%" src="/${data.image}" controls />
                      ${data.text ? data.text : ""}
                    </div>
                  </div>  
                  `);
                    } else if (data.file != null) {
                        $(".texts-container").append(`
                  <div class="${user_id}" id="${data.id}"> 
                  <img src="${user_image}"alt="">
                    <div class="${style_user}">
                      <a class="downloade-file-chat" href="${
                        data.file
                      }" controls ><i class="fa fa-file"></i></a><br><br>
                      ${data.text ? data.text : ""}
                    </div>
                  </div>  
                     <img src="flash/img/maneger.png"alt="">
               `);
                    } else {
                        $(".texts-container").append(`
                  <div class="${user_id}" id="${data.id}"> 
                  <img src="${user_image}"alt="">
                    <div class="${style_user}">
                    ${data.text}
                    </div>
                  </div>  
                  `);
                    }
                });
                $('.chateOther').remove();
                $(".texts-container").append(
                    `<button class="chateOther" onclick="chateOther()"><i class="fa fa-arrow-up"></i></button>`
                )
                chateOtherCounter++
            },
        });
    }
</script>
<?php /**PATH C:\Users\i\Downloads\idea\resources\views/admin/chat/chat.blade.php ENDPATH**/ ?>