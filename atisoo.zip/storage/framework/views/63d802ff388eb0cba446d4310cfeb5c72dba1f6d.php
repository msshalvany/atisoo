
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <section class="panel">
                <header class="panel-heading">
                    لیست فایل ها
                </header>
                <?php if($comments->hasPages()): ?>
                    <ul class="pagination pagination" style="display: flex">
                        
                        <?php if($comments->onFirstPage()): ?>
                            <li class="disabled"><span>«</span></li>
                        <?php else: ?>
                            <li><a href="<?php echo e($comments->appends(request()->input())->previousPageUrl()); ?>" rel="prev">«</a>
                            </li>
                        <?php endif; ?>

                        <?php if($comments->currentPage() > 3): ?>
                            <li class="hidden-xs"><a href="<?php echo e($comments->appends(request()->input())->url(1)); ?>">1</a></li>
                        <?php endif; ?>
                        <?php if($comments->currentPage() > 4): ?>
                            <li><span>...</span></li>
                        <?php endif; ?>
                        <?php $__currentLoopData = range(1, $comments->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($i >= $comments->currentPage() - 2 && $i <= $comments->currentPage() + 2): ?>
                                <?php if($i == $comments->currentPage()): ?>
                                    <li class="active"><span><?php echo e($i); ?></span></li>
                                <?php else: ?>
                                    <li><a
                                            href="<?php echo e($comments->appends(request()->input())->url($i)); ?>"><?php echo e($i); ?></a>
                                    </li>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if($comments->currentPage() < $comments->lastPage() - 3): ?>
                            <li><span>...</span></li>
                        <?php endif; ?>
                        <?php if($comments->currentPage() < $comments->lastPage() - 2): ?>
                            <li class="hidden-xs"><a
                                    href="<?php echo e($comments->url($comments->lastPage())); ?>"><?php echo e($comments->lastPage()); ?></a>
                            </li>
                        <?php endif; ?>

                        
                        <?php if($comments->hasMorePages()): ?>
                            <li><a href="<?php echo e($comments->appends(request()->input())->nextPageUrl()); ?>" rel="next">»</a>
                            </li>
                        <?php else: ?>
                            <li class="disabled"><span>»</span></li>
                        <?php endif; ?>
                    </ul>
                <?php endif; ?>
                <table class="table table-striped table-advance table-hover">
                    <thead>
                        <tr>
                            <td>متن</td>
                            <td>کاربر</td>
                            <td>دستگاه</td>
                            <td>حذف</td>
                            <td>آپدیت</td>
                        </tr>
                    </thead>
                    <tbody>

                        <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->text); ?></td>
                                <td><?php echo e($item->user_id); ?></td>
                                <td><?php echo e($item->device_id); ?></td>
                                <form  action="<?php echo e(route('commentDelete', ['id' => $item->id])); ?>"
                                    method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <td>
                                        <button class="btn btn-danger btn-xs"><i class="icon-trash "></i></button>
                                    </td>
                                </form>
                                <form action="<?php echo e(route('commentUpdateShow', ['id' => $item->id])); ?>" method="get">
                                    <?php echo csrf_field(); ?>
                                    <td>
                                        <button class="btn btn-primary btn-xs"><i class="icon-pencil "></i></button>
                                    </td>
                                </form>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
                <?php if($comments->hasPages()): ?>
                    <ul class="pagination pagination" style="display: flex">
                        
                        <?php if($comments->onFirstPage()): ?>
                            <li class="disabled"><span>«</span></li>
                        <?php else: ?>
                            <li><a href="<?php echo e($comments->appends(request()->input())->previousPageUrl()); ?>"
                                    rel="prev">«</a></li>
                        <?php endif; ?>

                        <?php if($comments->currentPage() > 3): ?>
                            <li class="hidden-xs"><a href="<?php echo e($comments->appends(request()->input())->url(1)); ?>">1</a></li>
                        <?php endif; ?>
                        <?php if($comments->currentPage() > 4): ?>
                            <li><span>...</span></li>
                        <?php endif; ?>
                        <?php $__currentLoopData = range(1, $comments->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($i >= $comments->currentPage() - 2 && $i <= $comments->currentPage() + 2): ?>
                                <?php if($i == $comments->currentPage()): ?>
                                    <li class="active"><span><?php echo e($i); ?></span></li>
                                <?php else: ?>
                                    <li><a
                                            href="<?php echo e($comments->appends(request()->input())->url($i)); ?>"><?php echo e($i); ?></a>
                                    </li>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if($comments->currentPage() < $comments->lastPage() - 3): ?>
                            <li><span>...</span></li>
                        <?php endif; ?>
                        <?php if($comments->currentPage() < $comments->lastPage() - 2): ?>
                            <li class="hidden-xs"><a
                                    href="<?php echo e($comments->url($comments->lastPage())); ?>"><?php echo e($comments->lastPage()); ?></a>
                            </li>
                        <?php endif; ?>

                        
                        <?php if($comments->hasMorePages()): ?>
                            <li><a href="<?php echo e($comments->appends(request()->input())->nextPageUrl()); ?>" rel="next">»</a>
                            </li>
                        <?php else: ?>
                            <li class="disabled"><span>»</span></li>
                        <?php endif; ?>
                    </ul>
                <?php endif; ?>
            </section>
            <?php if(count($comments) == 0): ?>
                <div style="text-align: center">موردی یافت نشد</div><br>
                <a style="text-align: center;display: block;" class="btn btn-primary" href="/dashbord/flashList">برگشت</a>
            <?php endif; ?>
        </div>
    </div>
    <?php if(session('updateFlashErr')): ?>
        <script !src="">
            alertEore('فایل موجود نیست')
        </script>
    <?php endif; ?>
    <?php if(session('byedErr')): ?>
        <script !src="">
            alertEore('فایل در سبد خرید فردی وجود دارد')
        </script>
    <?php endif; ?>
    <?php if(session('shopErr')): ?>
        <script !src="">
            alertEore('فایل را فردی خریده لطفا 24 ساعت صبر کنید')
        </script>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\i\Desktop\flash\resources\views\admin\comment\show.blade.php ENDPATH**/ ?>