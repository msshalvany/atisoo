
<?php $__env->startSection('css'); ?>
    <style>
        .chat-list-con {
            width: 100%;
        }

        .chat-list-item {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 5px 40px 5px 40px;
            background: #dddddd;
            margin: 16px 0 0 0;
            border-radius: 20px;
            position: relative;
        }
        .chat-list-item span{
            position: absolute;
            top: 18px;
            left: 120px;
        }

        .chat-list-item img {
            width: 50px;
            height: 50px;
            object-fit: cover;
        }

        .counr-notsee {
            background: #ff2f2f;
            width: 25px;
            height: 25px;
            text-align: center;
            line-height: 25px;
            color: white;
            font-weight: bold;
            border-radius: 50%;
            position: absolute;
            top: 0
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php if($chats->hasPages()): ?>
        <ul class="pagination pagination" style="display: flex">
            
            <?php if($chats->onFirstPage()): ?>
                <li class="disabled"><span>«</span></li>
            <?php else: ?>
                <li><a href="<?php echo e($chats->appends(request()->input())->previousPageUrl()); ?>" rel="prev">«</a>
                </li>
            <?php endif; ?>

            <?php if($chats->currentPage() > 3): ?>
                <li class="hidden-xs"><a href="<?php echo e($chats->appends(request()->input())->url(1)); ?>">1</a></li>
            <?php endif; ?>
            <?php if($chats->currentPage() > 4): ?>
                <li><span>...</span></li>
            <?php endif; ?>
            <?php $__currentLoopData = range(1, $chats->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($i >= $chats->currentPage() - 2 && $i <= $chats->currentPage() + 2): ?>
                    <?php if($i == $chats->currentPage()): ?>
                        <li class="active"><span><?php echo e($i); ?></span></li>
                    <?php else: ?>
                        <li><a href="<?php echo e($chats->appends(request()->input())->url($i)); ?>"><?php echo e($i); ?></a>
                        </li>
                    <?php endif; ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if($chats->currentPage() < $chats->lastPage() - 3): ?>
                <li><span>...</span></li>
            <?php endif; ?>
            <?php if($chats->currentPage() < $chats->lastPage() - 2): ?>
                <li class="hidden-xs"><a href="<?php echo e($chats->url($chats->lastPage())); ?>"><?php echo e($chats->lastPage()); ?></a>
                </li>
            <?php endif; ?>

            
            <?php if($chats->hasMorePages()): ?>
                <li><a href="<?php echo e($chats->appends(request()->input())->nextPageUrl()); ?>" rel="next">»</a>
                </li>
            <?php else: ?>
                <li class="disabled"><span>»</span></li>
            <?php endif; ?>
        </ul>
    <?php endif; ?>
    <div class="chat-list-con">
        <?php $__currentLoopData = $chats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $user = \App\Models\user::find($item->user_id);
                $chat = \App\Models\chate::find($item->id);
                $last_mess = \App\Models\messegeChat::where('chate_id', $chat->id)->max('id');
                $last_mess = \App\Models\messegeChat::find($last_mess);
            ?>
            <div class="chat-list-item"
                onclick="location.href='<?php echo e(route('chatAdmin', ['chate_id' => $item->id, 'user_id' => $user->id])); ?>'">
                <div>
                    <div style="font-weight: bold;font-size: 20px"><?php echo e($user->name); ?></div >
                        <?php if($last_mess != null): ?>
                        <span style="font-size: 8px"><?php echo e($last_mess->updated_at); ?></span>
                        <?php echo e($last_mess->text); ?>

                        <?php if($last_mess->text == ''): ?>
                            <i class="icon-file"></i>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
                <div style="position: relative;">
                    <img width="" style="border-radius:50%;order: 2" src="/<?php echo e($user->image); ?>" alt="">
                    <?php if($item->see_admin != 0): ?>
                        <div style="order: 1" class="counr-notsee">
                            پیام
                        </div>
                    <?php endif; ?>

                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php if($chats->hasPages()): ?>
        <ul class="pagination pagination" style="display: flex">
            
            <?php if($chats->onFirstPage()): ?>
                <li class="disabled"><span>«</span></li>
            <?php else: ?>
                <li><a href="<?php echo e($chats->appends(request()->input())->previousPageUrl()); ?>" rel="prev">«</a></li>
            <?php endif; ?>

            <?php if($chats->currentPage() > 3): ?>
                <li class="hidden-xs"><a href="<?php echo e($chats->appends(request()->input())->url(1)); ?>">1</a></li>
            <?php endif; ?>
            <?php if($chats->currentPage() > 4): ?>
                <li><span>...</span></li>
            <?php endif; ?>
            <?php $__currentLoopData = range(1, $chats->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($i >= $chats->currentPage() - 2 && $i <= $chats->currentPage() + 2): ?>
                    <?php if($i == $chats->currentPage()): ?>
                        <li class="active"><span><?php echo e($i); ?></span></li>
                    <?php else: ?>
                        <li><a href="<?php echo e($chats->appends(request()->input())->url($i)); ?>"><?php echo e($i); ?></a>
                        </li>
                    <?php endif; ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if($chats->currentPage() < $chats->lastPage() - 3): ?>
                <li><span>...</span></li>
            <?php endif; ?>
            <?php if($chats->currentPage() < $chats->lastPage() - 2): ?>
                <li class="hidden-xs"><a href="<?php echo e($chats->url($chats->lastPage())); ?>"><?php echo e($chats->lastPage()); ?></a>
                </li>
            <?php endif; ?>

            
            <?php if($chats->hasMorePages()): ?>
                <li><a href="<?php echo e($chats->appends(request()->input())->nextPageUrl()); ?>" rel="next">»</a>
                </li>
            <?php else: ?>
                <li class="disabled"><span>»</span></li>
            <?php endif; ?>
        </ul>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\i\Documents\laravel\resources\views/admin/chat/chatlist.blade.php ENDPATH**/ ?>