
<?php $__env->startSection('title'); ?>
<?php echo e($device->name1); ?>

<?php $__env->stopSection(); ?>
<?php
    $text = [];
    $tKes= explode(',',$info->deviceKey);
    foreach ($tKes as $value) {
        $new = str_replace('*',$device->lable,$value);
        array_push($text,$new);
        $new = str_replace('*',$device->ipromName,$value);
        array_push($text,$new);
        $new = str_replace('*',$device->name1,$value);
        array_push($text,$new);
        $new = str_replace('*',$device->name2,$value);
        array_push($text,$new);
        $new = str_replace('*',$device->name3,$value);
        array_push($text,$new);
        $new = str_replace('*',$device->ic,$value);
        array_push($text,$new);
    }
    $text = implode(',',$text);
?>
<?php $__env->startSection('keys'); ?><?php echo e($text); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <style>
        .home {
            position: fixed;
            top: 5px;
            left: 80px;
            text-align: center;
            font-weight: bold;
            color: white;
            background-color: #ff4141;
            padding: 5px 15px;
            border-radius: 12px;
            z-index: 12;
            font-size: 12px;
        }

        .fa-shopping-cart {
            font-size: 32px;
            position: relative;
            cursor: pointer;
        }
        .flash-cont,
        .flash-cont-by-for-you {
            margin-top: 200px;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <a href="/">
        <div class="home"><i class="fa fa-home"></i><br>صفحه اصلی </div>
    </a>
    <div class="flash-cont flash-cont-show">
        <div class="flash-by-cont flash-by-cont-show">
            <ul id="<?php echo e($device->id); ?>">
                <li>
                    فایل فلش : <?php echo e($device->flashPrice); ?> هزار تومان <input type="checkbox" name="" class="flash" />
                </li>
                <br />
                <?php if($device->iprom != 'false'): ?>
                    <li>
                        فایل ایپروم : <?php echo e($device->ipromPrice); ?> هزار تومان <input type="checkbox" name=""
                            class="iprom" />
                    </li>
                <?php endif; ?>
            </ul>

            <button class="addShop">افزودن به سبد خرید</button>
        </div>
       <div class="flash-dis-cont">
            <div>آیدی سایت : <span><?php echo e($device->id2); ?></span></div>
            <div>کد روی برد : <span><?php echo e($device->name1); ?></span></div>
            <div>کد پشت برد : <span><?php echo e($device->name2); ?></span></div>
            <div>برچسب روی برد : <span><?php echo e($device->name3); ?></span></div>
            <div>پردازنده : <span><?php echo e($device->ic); ?></span></div>
            <div>لیبل : <span><?php echo e($device->lable); ?></span></div>
            <div>تعداد کانال : <span><?php echo e($device->chanel); ?></span></div>
            <?php if($device->ipromName != 'null'): ?>
                <div> نام ای سی ایپروم: <span><?php echo e($device->ipromName); ?></span></div>
            <?php endif; ?>
            <br>
            <div>رمز: <span><?php echo e($device->password); ?></span></div>
            <div>سایز فایل: <span><?php echo e($device->flashSize); ?></span></div>
            <br>
            <div>
                توضیحات :
                <p>
                    <?php echo e($device->description); ?>

                </p>
            </div>
        </div>
        <div class="flash-img-cont">
            <div class="slider">
                <?php
                    $imags = json_decode($device->imags);
                ?>
                <?php $__currentLoopData = $imags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="img-magnifier-container">
                    <img class="myimage" src="/<?php echo e($img); ?>" alt="موردی یافت نشد" />
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="next fa fa-right-long"></div>
                <div class="prev fa fa-left-long"></div>
            </div>
        </div>
    </div>
    <P style="text-align: center ;font-size: 34px;font-weight: bold">نظرات همکاران</P>
    <ul class="comments">
        <?php $__currentLoopData = $comment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                کاربر شماره <?php echo e($item->user_id); ?> <br>
                <?php echo e($item->text); ?>

            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('flash.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/atisooir/lara/resources/views/flash/showDevice.blade.php ENDPATH**/ ?>