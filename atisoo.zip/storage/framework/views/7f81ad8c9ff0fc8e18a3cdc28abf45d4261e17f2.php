<?php $__env->startSection('css'); ?>
<style>
    *{
        color: black
    }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
   <section class="forms-start">
    <a href="/"><div class="home"><i style="color: white" class="fa fa-home"></i><br>صفحه اصلی </div></a>
        <form class="regester" action="<?php echo e(route('login')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <label for="phon">شماره همراه خود را وارد کنید :</label>
            <input type="text" class="phon" name="phon" placeholder="مثال : 09131572450">
            <label for="password">رمز خود را وارد کنید:</label>
            <input type="text" class="password" name="password" placeholder="حداقل 4 رقمی">
            <a style="text-decoration: underline" href="<?php echo e(route('resePassVwie')); ?>">رمز عبور را فراموش کرده ام </a>
            <input type="submit" value="وارد شوید">
        </form>
   </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php if(session('erroreLogin')): ?>
    <?php if(session('erroreLogin') == 'data'): ?>
        <script !src="">
            alertEore('اطلاعات را صحیح وارد کنید')
        </script>
    <?php endif; ?>
    <?php if(session('erroreLogin') == 'null'): ?>
        <script !src="">
            alertEore('رمز یا نام کاربری اشتباه است')
        </script>
    <?php endif; ?>
<?php endif; ?>
    <script>
        $('.login-regester').css('box-shadow', '0px 8px 5px rgb(122 122 122)');
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('flash.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\i\Documents\laravel\resources\views/flash/login.blade.php ENDPATH**/ ?>