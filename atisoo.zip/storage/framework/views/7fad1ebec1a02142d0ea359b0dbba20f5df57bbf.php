<?php $__env->startSection('keys'); ?>
    <?php echo e($info->indexKey); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>
    خدمات آنلاین مدار بسته
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <style>
        .byForYou {
            display: none
        }

        .abute {
            display: none
        }

        .dropdao-btn-container {
            display: none
        }

        .searchViwe {
            display: none
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="section1">
        <img src="<?php echo e($info->logo); ?>" class="logo-img" alt="موردی یافت نشد"><br>
        <h1>خدمات آنلاین دوربین مداربسته و dvr , nvr</h1><br>
        
        <div class="count-user-file">
            <div class="count-user">
                <div class="icon"><i class="fa fa-user"></i></div>
                <div class="count"><?php echo e($userCount); ?></div>
                <p>تعداد ثبت نام کنندگان</p>
            </div>
            
        </div>
        <div class="circle-menue">
            <a href="/resetDe"><p>ریست پسورد DVR , NVR</p><span style="color: red;text-shadow: none">(برای عموم مردم)</span></a>
            <a href="/resetCa"><p>ریست پسورد دوربین ip</p><span style="color: red;text-shadow: none">(برای عموم مردم)</span></a>
            <a class="updateBtn" href=""><p>جستجوی فایل آپدیت</p><span style="color: black;text-shadow: none;font-size: 12px">(برای نصاب ها و  تعمیرکاران)</span></a>
            <a href="/searchViwe"><p>جستجوی فایل فلش</p><span style="color: black;text-shadow: none;font-size: 12px">(برای نصاب ها و تعمیرکاران)</span></a>
            <a href="/byForYou"><P>خرید فایل فلش  از تعمیرکاران</P></a>
            <a class="updateBtnBy" href=""><p>خرید  فایل آپدیت از تعمیرکاران</p></a>
            <a href="/abute"><p>درباره ما</p></a>
        </div>
    </section>

    
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script !src="">
        $('.updateBtn').click(function(e) {
            e.preventDefault();
            alertSucsses('در حال توسعه به زودی فعال میشود')
        });
        $('.updateBtnBy').click(function(e) {
            e.preventDefault();
            alertSucsses('در حال توسعه به زودی فعال میشود')
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('flash.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\i\Documents\laravel\resources\views/flash/index.blade.php ENDPATH**/ ?>