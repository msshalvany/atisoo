<?php $__env->startSection('title'); ?>
    درباره ما
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <style>
        .abute-dic {
            padding: 120px;
        }

        .abute-galoru ul {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <a href="/">
        <div class="home"><i class="fa fa-home"></i><br>صفحه اصلی </div>
    </a>
    <div class="abute-dic">
        <ul>
            <li><b>آدرس مرکز تعمیرات آتی سو : </b>استان یزد ، شهرستان یزد
                خیابان فرخی ، پاساژ فرخی
                طبقه همکف ، آخرین مغازه
                (تعمیرات دوربین مداربسته)
                کد پستی : 8913893654</li>
            <li><b>همراه: </b>09217902890</li>
        </ul>
        
    </div>
    <div class="abute-galoru">
        <ul>
            <img width="60%" src="/flash/img/about2.jpg" alt="موردی یافت نشد">
            <img width="60%" src="/flash/img/about1.jpg" alt="موردی یافت نشد">
        </ul>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        $('.abute').css('box-shadow', '0px 8px 5px rgb(122 122 122) ');
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('flash.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\i\Desktop\atisoo\resources\views/flash/abute.blade.php ENDPATH**/ ?>