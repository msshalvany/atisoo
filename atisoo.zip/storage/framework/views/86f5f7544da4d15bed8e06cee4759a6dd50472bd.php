
<?php $__env->startSection('keys'); ?><?php echo e($info->byFlahYouKey); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>
    خرید از شما
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <a href="/">
        <div class="home"><i class="fa fa-home"></i><br>صفحه اصلی </div>
    </a>
    <section style="margin-top: 120px" class="section1">
        <img src="<?php echo e($info->logo); ?>" class="logo-img" alt="موردی یافت نشد"><br>
        <h1>خرید فایل فلش و آپدیت از شما</h1><br>
    </section>
    <section class="by-for-you-contaoner">
        <ul>
            <?php if($device != 'null'): ?>
                <?php $__currentLoopData = $device; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="flash-cont-by-for-you">
                        <div class="flash-dis-cont-by-for-you">
                            <div> آیدی سایت : <span><?php echo e($item->id2); ?></span></div>
                            <div>کد روی برد : <span><?php echo e($item->name1); ?></span></div>
                            <div>کد پشت برد : <span><?php echo e($item->name2); ?></span></div>
                            <div>برچسب روی برد : <span><?php echo e($item->name3); ?></span></div>
                            <div>پردازنده : <span><?php echo e($item->ic); ?></span></div>
                            <div>لیبل: <span><?php echo e($item->lable); ?></span></div>
                            <div>تعداد کانال : <span><?php echo e($item->chanel); ?></span></div>
                            <div> نام ای سی ایپروم: <span><?php echo e($item->ipromName); ?></span></div>
                            <div><br>
                                توضیحات :
                                <br>
                                <audio src="<?php echo e($item->mp3); ?>" controls></audio>
                            </div>
                            <br>
                            <div><br>
                                توضیحات  متنی:
                                <br>
                                <p>
                                    <?php echo e($item->description); ?>

                                </p>
                            </div><br>
                        </div>
                        <div class="flash-img-cont">
                            <div class="slider">
                                <?php
                                    $imags = json_decode($item->imags);
                                ?>
                                <?php $__currentLoopData = $imags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="img-magnifier-container">
                                        <img class="myimage" src="<?php echo e($img); ?>" alt="موردی یافت نشد" />
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <div class="next fa fa-right-long"></div>
                                <div class="prev fa fa-left-long"></div>
                            </div>
                            <div>
                               قیمت پیشنهادی :
                                <span style="color: red; font-weight: bold"><?php echo e($item->price); ?> هزار تومان </span>
                            </div>
                        </div>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <?php if(count($device) == 0): ?>
                موردی در حال حال حاضر وجود ندارد
            <?php endif; ?>
        </ul>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        $('.byForYou').css('box-shadow', '0px 8px 5px rgb(122 122 122)');
    </script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('flash.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\i\Desktop\atisoo\resources\views/flash/byForYou.blade.php ENDPATH**/ ?>