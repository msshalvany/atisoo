<?php $__env->startSection('content'); ?>
    <span>جمع کل خرید ها : </span> <?php echo e($data->count); ?><br> <br>
    <span>جمع کل</span> : <?php echo e($data->total); ?> هزار تومان<br><br>
    <br><br>
    <form action="<?php echo e(route('resetMonny')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <button class="btn btn-info">resete</button>
    </form>
    <h3>تعویض قیمت تمام فایل ها</h3>
            <form class="container row conf-form" action="<?php echo e(route('updatPiceALL')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <label for="">فایل فلش : </label>
                <input style="width: 240px;display: inline" class="form-control" name="flash" value="50"
                    type="number"><br><br>
                <label for="">فایل اپروم : </label>
                <input style="width: 240px;display: inline" class="form-control" name="iprom" value="20"
                    type="number"><br><br>
                <input type="submit" value="انجام" class="btn btn-primary">
            </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/atisooir/lara/resources/views/admin/index.blade.php ENDPATH**/ ?>