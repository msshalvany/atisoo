<?php $__env->startSection('content'); ?>
    <span>جمع کل خرید ها : </span> <?php echo e($data->count); ?><br> <br>
    <span>جمع کل</span> : <?php echo e($data->total); ?> هزار تومان<br><br>
    <br><br>
    <form action="<?php echo e(route('resetMonny')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <button class="btn btn-info">resete</button>
    </form>
    <form role="form" action="<?php echo e(route('flashLodear')); ?>" method="POST" enctype="multipart/form-data" autocomplete="off">
        <?php echo csrf_field(); ?>
        <button style="margin-top: 12px;" type="submit" name="btn" class="btn btn-info">بروزرسانی فایل های فلش
        </button>
    </form>
    <form role="form" action="<?php echo e(route('resetPassDvrNvrLoder')); ?>" method="POST" enctype="multipart/form-data" autocomplete="off">
        <?php echo csrf_field(); ?>
        <button style="margin-top: 12px;" type="submit" name="btn" class="btn btn-info"> بروزرسانی ریست پسورد  DVR NVR 
        </button>
    </form>
    <form role="form" action="<?php echo e(route('resetPassCamLoder')); ?>" method="POST" enctype="multipart/form-data" autocomplete="off">
        <?php echo csrf_field(); ?>
        <button style="margin-top: 12px;" type="submit" name="btn" class="btn btn-info">بروزرسانی ریست پسورد CAM
        </button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\i\Desktop\flash\resources\views\admin\index.blade.php ENDPATH**/ ?>