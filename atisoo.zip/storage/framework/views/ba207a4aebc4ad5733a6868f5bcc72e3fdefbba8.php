<?php $__env->startSection('content'); ?>
    <div class="conf-cont">
        <p>ایا از انجام این عملیات مطمعن هستید</p>
        <div>
            <button class="cancel">کنسل</button>
            <button class="submit">مطمعن</button>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <form class="container row" action="<?php echo e(route('flashSearch')); ?>">
                <input style="width: 240px;display: inline" class="form-control" name="text" type="text">
                <input type="submit" value="جستوجو" class="btn btn-primary">
            </form><br>
            <h3>تعویض قیمت تمام فایل ها</h3>
            <form class="container row conf-form" action="<?php echo e(route('updatPiceALL')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <label for="">فایل فلش : </label>
                <input style="width: 240px;display: inline" class="form-control" name="flash" value="50"
                    type="number"><br><br>
                <label for="">فایل اپروم : </label>
                <input style="width: 240px;display: inline" class="form-control" name="iprom" value="20"
                    type="number"><br><br>
                <input type="submit" value="انجام" class="btn btn-primary">
            </form>
            <br>
            <section class="panel">
                <header class="panel-heading">
                    لیست فایل ها
                </header>
                <?php if($device->hasPages()): ?>
                    <ul class="pagination pagination" style="display: flex">
                        
                        <?php if($device->onFirstPage()): ?>
                            <li class="disabled"><span>«</span></li>
                        <?php else: ?>
                            <li><a href="<?php echo e($device->appends(request()->input())->previousPageUrl()); ?>" rel="prev">«</a>
                            </li>
                        <?php endif; ?>

                        <?php if($device->currentPage() > 3): ?>
                            <li class="hidden-xs"><a href="<?php echo e($device->appends(request()->input())->url(1)); ?>">1</a></li>
                        <?php endif; ?>
                        <?php if($device->currentPage() > 4): ?>
                            <li><span>...</span></li>
                        <?php endif; ?>
                        <?php $__currentLoopData = range(1, $device->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($i >= $device->currentPage() - 2 && $i <= $device->currentPage() + 2): ?>
                                <?php if($i == $device->currentPage()): ?>
                                    <li class="active"><span><?php echo e($i); ?></span></li>
                                <?php else: ?>
                                    <li><a
                                            href="<?php echo e($device->appends(request()->input())->url($i)); ?>"><?php echo e($i); ?></a>
                                    </li>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if($device->currentPage() < $device->lastPage() - 3): ?>
                            <li><span>...</span></li>
                        <?php endif; ?>
                        <?php if($device->currentPage() < $device->lastPage() - 2): ?>
                            <li class="hidden-xs"><a
                                    href="<?php echo e($device->url($device->lastPage())); ?>"><?php echo e($device->lastPage()); ?></a>
                            </li>
                        <?php endif; ?>

                        
                        <?php if($device->hasMorePages()): ?>
                            <li><a href="<?php echo e($device->appends(request()->input())->nextPageUrl()); ?>" rel="next">»</a>
                            </li>
                        <?php else: ?>
                            <li class="disabled"><span>»</span></li>
                        <?php endif; ?>
                    </ul>
                <?php endif; ?>
                <table class="table table-striped table-advance table-hover">
                    <thead>
                        <tr>
                            <td>id</td>
                            <td>نام</td>
                            <td>نمایش</td>
                            <td>حذف</td>
                            <td>آپدیت</td>
                        </tr>
                    </thead>
                    <tbody>

                        <?php $__currentLoopData = $device; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->id2); ?></td>
                                <td><?php echo e($item->name1); ?></td>
                                <form class="" action="<?php echo e(route('flashShow', ['id' => $item->id])); ?>"
                                    method="GET">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <td>
                                        <button class="btn btn-success btn-xs"><i class="icon-picture"></i></button>
                                    </td>
                                </form>
                                <form class="conf-form" action="<?php echo e(route('flashDelete', ['id' => $item->id])); ?>"
                                    method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <td>
                                        <button class="btn btn-danger btn-xs"><i class="icon-trash "></i></button>
                                    </td>
                                </form>
                                <form action="<?php echo e(route('flashUpdate', ['id' => $item->id])); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <td>
                                        <button class="btn btn-primary btn-xs"><i class="icon-pencil "></i></button>
                                    </td>
                                </form>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
                <?php if($device->hasPages()): ?>
                    <ul class="pagination pagination" style="display: flex">
                        
                        <?php if($device->onFirstPage()): ?>
                            <li class="disabled"><span>«</span></li>
                        <?php else: ?>
                            <li><a href="<?php echo e($device->appends(request()->input())->previousPageUrl()); ?>"
                                    rel="prev">«</a></li>
                        <?php endif; ?>

                        <?php if($device->currentPage() > 3): ?>
                            <li class="hidden-xs"><a href="<?php echo e($device->appends(request()->input())->url(1)); ?>">1</a></li>
                        <?php endif; ?>
                        <?php if($device->currentPage() > 4): ?>
                            <li><span>...</span></li>
                        <?php endif; ?>
                        <?php $__currentLoopData = range(1, $device->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($i >= $device->currentPage() - 2 && $i <= $device->currentPage() + 2): ?>
                                <?php if($i == $device->currentPage()): ?>
                                    <li class="active"><span><?php echo e($i); ?></span></li>
                                <?php else: ?>
                                    <li><a
                                            href="<?php echo e($device->appends(request()->input())->url($i)); ?>"><?php echo e($i); ?></a>
                                    </li>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if($device->currentPage() < $device->lastPage() - 3): ?>
                            <li><span>...</span></li>
                        <?php endif; ?>
                        <?php if($device->currentPage() < $device->lastPage() - 2): ?>
                            <li class="hidden-xs"><a
                                    href="<?php echo e($device->url($device->lastPage())); ?>"><?php echo e($device->lastPage()); ?></a>
                            </li>
                        <?php endif; ?>

                        
                        <?php if($device->hasMorePages()): ?>
                            <li><a href="<?php echo e($device->appends(request()->input())->nextPageUrl()); ?>" rel="next">»</a>
                            </li>
                        <?php else: ?>
                            <li class="disabled"><span>»</span></li>
                        <?php endif; ?>
                    </ul>
                <?php endif; ?>
            </section>
            <?php if(count($device) == 0): ?>
                <div style="text-align: center">موردی یافت نشد</div><br>
                <a style="text-align: center;display: block;" class="btn btn-primary" href="/dashbord/flashList">برگشت</a>
            <?php endif; ?>
        </div>
    </div>
    <?php if(session('updateFlashErr')): ?>
        <script !src="">
            alertEore('فایل موجود نیست')
        </script>
    <?php endif; ?>
    <?php if(session('byedErr')): ?>
        <script !src="">
            alertEore('فایل در سبد خرید فردی وجود دارد')
        </script>
    <?php endif; ?>
    <?php if(session('shopErr')): ?>
        <script !src="">
            alertEore('فایل را فردی خریده لطفا 24 ساعت صبر کنید')
        </script>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\i\Desktop\flash\resources\views\admin\flash\list.blade.php ENDPATH**/ ?>