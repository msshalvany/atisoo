 
 <?php $__env->startSection('content'); ?>
     <div class="row">
         <h3 style="margin-right: 12px"><b>تعداد کاربران : <?php echo e($count); ?></b></h3>
         <div class="col-lg-12">
            <form class="container row" action="<?php echo e(route('userSearch')); ?>">
                <input style="width: 240px;display: inline" class="form-control" name="text" type="text">
                <input type="submit" value="جستوجو" class="btn btn-primary">
            </form>
            <br>
             <section class="panel">
                 <header class="panel-heading">
                     لیست کابران
                 </header>
                 <?php if($user->hasPages()): ?>
                     <ul class="pagination pagination" style="display: flex">
                         
                         <?php if($user->onFirstPage()): ?>
                             <li class="disabled"><span>«</span></li>
                         <?php else: ?>
                             <li><a href="<?php echo e($user->appends(request()->input())->previousPageUrl()); ?>" rel="prev">«</a>
                             </li>
                         <?php endif; ?>

                         <?php if($user->currentPage() > 3): ?>
                             <li class="hidden-xs"><a href="<?php echo e($user->appends(request()->input())->url(1)); ?>">1</a></li>
                         <?php endif; ?>
                         <?php if($user->currentPage() > 4): ?>
                             <li><span>...</span></li>
                         <?php endif; ?>
                         <?php $__currentLoopData = range(1, $user->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <?php if($i >= $user->currentPage() - 2 && $i <= $user->currentPage() + 2): ?>
                                 <?php if($i == $user->currentPage()): ?>
                                     <li class="active"><span><?php echo e($i); ?></span></li>
                                 <?php else: ?>
                                     <li><a href="<?php echo e($user->appends(request()->input())->url($i)); ?>"><?php echo e($i); ?></a>
                                     </li>
                                 <?php endif; ?>
                             <?php endif; ?>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         <?php if($user->currentPage() < $user->lastPage() - 3): ?>
                             <li><span>...</span></li>
                         <?php endif; ?>
                         <?php if($user->currentPage() < $user->lastPage() - 2): ?>
                             <li class="hidden-xs"><a href="<?php echo e($user->url($user->lastPage())); ?>"><?php echo e($user->lastPage()); ?></a>
                             </li>
                         <?php endif; ?>

                         
                         <?php if($user->hasMorePages()): ?>
                             <li><a href="<?php echo e($user->appends(request()->input())->nextPageUrl()); ?>" rel="next">»</a></li>
                         <?php else: ?>
                             <li class="disabled"><span>»</span></li>
                         <?php endif; ?>
                     </ul>
                 <?php endif; ?>
                 <table class="table table-striped table-advance table-hover">
                     <thead>
                         <tr>
                             <td>نام</td>
                             <td>id</td>
                             <td>شماره</td>
                             <td>نام مغازه</td>
                             <td>شهر</td>
                         </tr>
                     </thead>
                     <tbody>
                         <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <tr>
                                 <td><?php echo e($user->name); ?></td>
                                 <td><?php echo e($user->id); ?></td>
                                 <td><?php echo e($user->phon); ?></td>
                                 <td><?php echo e($user->stor); ?></td>
                                 <td><?php echo e($user->city); ?></td>
                             </tr>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </tbody>
                 </table>
             </section>
         </div>
         <?php if($count == 0): ?>
             <div style="text-align: center">موردی یافت نشد</div><br>
             <a style="text-align: center;display: block;" class="btn btn-primary" href="/dashbord/userList">برگشت</a>
         <?php endif; ?>
     </div>
 <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/atisooir/lara/resources/views/admin/userList.blade.php ENDPATH**/ ?>