
<?php $__env->startSection('keys'); ?><?php echo e($info->searchFlashKey); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>
     جستجوی فایل فلش
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <style>
        .section1 {
            margin-top: 120px
        }   
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <a href="/">
        <div class="home"><i class="fa fa-home"></i><br>صفحه اصلی </div>
    </a>
    <section class="section1">
        <img src="<?php echo e($info->logo); ?>" class="logo-img" alt="موردی یافت نشد"><br>
        <h1 style="text-align: center;display: block;width: 100%;"> موتور جستجوی فایل فلش</h1><br>
        <div class="count-user-file">
            
            <div class="file-count">
                <div class="icon"><i class="fa fa-file"></i></div>
                <div class="count"><?php echo e($fileCount); ?></div>
                <p>تعداد فایل های آپلود شده</p>
            </div>
        </div>
        <p style="text-align: center;padding: 0 12px"> در صورتی که فایلی را پیدا نکردید در <span style="color: red"> چت با مدیریت </span>  پیام دهید  </p><br>
        <form action="<?php echo e(route('search')); ?>" class="search" method="get">
            <input type="text" name="text"
                placeholder="نام روی برد یا برچسب پشت دستگاه یا دوربین را تایپ کنید ......." />
            <button><i style="color: rgb(88, 88, 88)" class="fa fa-search"></i></button>
        </form>
    </section>
    <section class="section2">
        
        <?php if($device != 'null'): ?>
            <?php if($device->hasPages()): ?>
                <ul class="pagination" style="display: flex">
                    
                    <?php if($device->onFirstPage()): ?>
                        <li class="disabled"><span>«</span></li>
                    <?php else: ?>
                        <li><a href="<?php echo e($device->appends(request()->input())->previousPageUrl()); ?>" rel="prev">«</a>
                        </li>
                    <?php endif; ?>

                    <?php if($device->currentPage() > 3): ?>
                        <li class="hidden-xs"><a href="<?php echo e($device->appends(request()->input())->url(1)); ?>">1</a> </li>
                    <?php endif; ?>
                    <?php if($device->currentPage() > 4): ?>
                        <li><span>...</span></li>
                    <?php endif; ?>
                    <?php $__currentLoopData = range(1, $device->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($i >= $device->currentPage() - 2 && $i <= $device->currentPage() + 2): ?>
                            <?php if($i == $device->currentPage()): ?>
                                <li class="active"><span><?php echo e($i); ?></span></li>
                            <?php else: ?>
                                <li><a href="<?php echo e($device->appends(request()->input())->url($i)); ?>"><?php echo e($i); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php if($device->currentPage() < $device->lastPage() - 3): ?>
                        <li><span>...</span></li>
                    <?php endif; ?>
                    <?php if($device->currentPage() < $device->lastPage() - 2): ?>
                        <li class="hidden-xs"><a
                                href="<?php echo e($device->url($device->lastPage())); ?>"><?php echo e($device->lastPage()); ?></a>
                        </li>
                    <?php endif; ?>

                    
                    <?php if($device->hasMorePages()): ?>
                        <li><a href="<?php echo e($device->appends(request()->input())->nextPageUrl()); ?>" rel="next">»</a>
                        </li>
                    <?php else: ?>
                        <li class="disabled"><span>»</span></li>
                    <?php endif; ?>
                </ul>
            <?php endif; ?>
        <?php endif; ?>
        <ul>
            <?php if($device != 'null'): ?>
                <?php $__currentLoopData = $device; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="flash-cont">
                        <div class="flash-dis-cont">
                            <div>آیدی سایت : <span><?php echo e($item->id2); ?></span></div>
                            <div>کد روی برد : <span><?php echo e($item->name1); ?></span></div>
                            <div>کد پشت برد : <span><?php echo e($item->name2); ?></span></div>
                            <div>برچسب روی برد : <span><?php echo e($item->name3); ?></span></div>
                            <div>پردازنده : <span><?php echo e($item->ic); ?></span></div>
                            <div>لیبل: <span><?php echo e($item->lable); ?></span></div>
                            <div>تعداد کانال : <span><?php echo e($item->chanel); ?></span></div>
                            <?php if($item->ipromName != 'null'): ?>
                                <div> نام ای سی ایپروم: <span><?php echo e($item->ipromName); ?></span></div>
                            <?php endif; ?>
                            <br>
                            <a class="show-device" href="showDevice/<?php echo e($item->id); ?>">مشاهده جزئیات و خرید</a>
                        </div>
                        <div class="flash-img-cont">
                            <div class="slider">
                                <?php
                                    $imags = json_decode($item->imags);
                                ?>
                                <?php $__currentLoopData = $imags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="img-magnifier-container">
                                        <img class="myimage" src="<?php echo e($img); ?>" alt="موردی یافت نشد" />
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <div class="next fa fa-right-long"></div>
                                <div class="prev fa fa-left-long"></div>
                            </div>
                        </div>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </ul>
        <?php if($device != 'null'): ?>
            <?php if($device->hasPages()): ?>
                <ul class="pagination" style="display: flex">
                    
                    <?php if($device->onFirstPage()): ?>
                        <li class="disabled"><span>«</span></li>
                    <?php else: ?>
                        <li><a href="<?php echo e($device->appends(request()->input())->previousPageUrl()); ?>" rel="prev">«</a>
                        </li>
                    <?php endif; ?>

                    <?php if($device->currentPage() > 3): ?>
                        <li class="hidden-xs"><a href="<?php echo e($device->appends(request()->input())->url(1)); ?>">1</a> </li>
                    <?php endif; ?>
                    <?php if($device->currentPage() > 4): ?>
                        <li><span>...</span></li>
                    <?php endif; ?>
                    <?php $__currentLoopData = range(1, $device->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($i >= $device->currentPage() - 2 && $i <= $device->currentPage() + 2): ?>
                            <?php if($i == $device->currentPage()): ?>
                                <li class="active"><span><?php echo e($i); ?></span></li>
                            <?php else: ?>
                                <li><a href="<?php echo e($device->appends(request()->input())->url($i)); ?>"><?php echo e($i); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php if($device->currentPage() < $device->lastPage() - 3): ?>
                        <li><span>...</span></li>
                    <?php endif; ?>
                    <?php if($device->currentPage() < $device->lastPage() - 2): ?>
                        <li class="hidden-xs"><a
                                href="<?php echo e($device->url($device->lastPage())); ?>"><?php echo e($device->lastPage()); ?></a>
                        </li>
                    <?php endif; ?>

                    
                    <?php if($device->hasMorePages()): ?>
                        <li><a href="<?php echo e($device->appends(request()->input())->nextPageUrl()); ?>" rel="next">»</a>
                        </li>
                    <?php else: ?>
                        <li class="disabled"><span>»</span></li>
                    <?php endif; ?>
            <?php endif; ?>
            </ul>
        <?php endif; ?>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        $('.dropdao-btn').eq(1).css('box-shadow', '0px 8px 5px rgb(54 0 124)');
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('flash.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/atisooir/lara/resources/views/flash/searchFlash.blade.php ENDPATH**/ ?>