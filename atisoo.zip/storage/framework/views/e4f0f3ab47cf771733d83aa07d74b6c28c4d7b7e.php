
<?php $__env->startSection('content'); ?>
    <table class="table table-striped">
        <tbody>
            <tr>
                <th scope="row">ایدی سایت</th>
                <td><?php echo e($device->id2); ?></td>
            </tr>
            <tr>
                <th scope="row">کد روی برد</th>
                <td><?php echo e($device->name1); ?></td>
            </tr>
            <tr>
                <th scope="row">کد پشت برد</th>
                <td><?php echo e($device->name2); ?></td>
            </tr>
            <tr>
                <th scope="row">کد روی برچسب برد</th>
                <td><?php echo e($device->name3); ?></td>
            </tr>
            <tr>
                <th scope="row">ic</th>
                <td><?php echo e($device->ic); ?></td>
            </tr>
            <tr>
                <th scope="row"> lable</th>
                <td><?php echo e($device->lable); ?></td>
            </tr>
            <tr>
                <th scope="row">chanel</th>
                <td><?php echo e($device->chanel); ?></td>
            </tr>
            <tr>
                <th scope="row">size</th>
                <td><?php echo e($device->flashSize); ?></td>
            </tr>
            <tr>
                <th scope="row">password</th>
                <td><?php echo e($device->password); ?></td>
            </tr>
            <tr>
                <th scope="row">توضیحات</th>
                <td><?php echo e($device->description); ?></td>
            </tr>
        </tbody>
    </table>
    <b style="font-size: 24px">نظر کاربران</b><br><br>
    <ul class="list-group">
        <?php $__currentLoopData = $comment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="list-group-item"><?php echo e($item->text); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\i\Documents\laravel\resources\views/admin/flash/show.blade.php ENDPATH**/ ?>