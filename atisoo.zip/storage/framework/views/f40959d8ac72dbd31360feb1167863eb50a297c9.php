
<?php $__env->startSection('title'); ?>
    ریست رمز پنل کاربری
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php
        $user = \App\Models\user::find(session()->get('user'));
    ?>
    <a href="/">
        <div class="home"><i class="fa fa-home"></i><br>صفحه اصلی </div>
    </a>
    <div class="mask"></div>
    <div class="tabs">
        <div id="tabs-nav">
            <ul style="display: flex">
                <li class="active"><a href="#tab1" id="by-tab">سبد خرید</a></li>
                <li><a href="#tab2" id="down-tab">دانلود فایل</a></li>
            </ul>
            <div>
                <span>شماره کاربری : <?php echo e($user->id); ?></span>
                <span>مقدار تخفیف شما : <?php echo e($user->discount); ?> هزار تومان </span>
            </div>
            
        </div>
        <!-- END tabs-nav -->
        <div id="tabs-content">
            <div id="tab1" class="tab-content tab-content1">
                <section class="section2">
                    <?php
                        $count = 0;
                    ?>
                    <?php if(count($deviceShop) == 0): ?>
                        <b>موردی یافت نشد</b>
                    <?php else: ?>
                        <ul>
                            <?php $__currentLoopData = $deviceShop; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deviceShop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="flash-cont">
                                    <div class="flash-by-cont">
                                        <ul>
                                            <?php if($deviceShop->flash != 'false'): ?>
                                                <li>
                                                    <?php
                                                        $price = \App\Models\device::find($deviceShop->deviceId)->flashPrice;
                                                        $count += $price;
                                                    ?>
                                                    فایل فلش : <?php echo e($price); ?> هزار تومان
                                                </li>
                                            <?php endif; ?>
                                            <br />
                                            <?php if($deviceShop->iprom != 'false'): ?>
                                                <?php
                                                    $price = \App\Models\device::find($deviceShop->deviceId)->ipromPrice;
                                                    $count += $price;
                                                    
                                                ?>
                                                <li>
                                                    فایل اپروم : <?php echo e($price); ?> هزار تومان
                                                </li>
                                            <?php endif; ?>
                                        </ul>
                                        <br>
                                        <form action="<?php echo e(route('deleteFlash', ['id' => $deviceShop->id])); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('delete'); ?>
                                            <button>حذف</button>
                                        </form>
                                    </div>
                                    <div class="flash-dis-cont">
                                        <?php
                                            $device = \App\Models\device::where('id', $deviceShop->deviceId)->first();
                                        ?>
                                        <div>آیدی سایت : <span><?php echo e($device->id2); ?></span></div>
                                        <div>کد روی برد : <span><?php echo e($device->name1); ?></span></div>
                                        <div>کد پشت برد : <span><?php echo e($device->name2); ?></span></div>
                                        <div>برچسب روی برد : <span><?php echo e($device->name3); ?></span></div>
                                        <div>پردازنده : <span><?php echo e($device->ic); ?></span></div>
                                        <div>لیبل: <span><?php echo e($device->lable); ?></span></div>
                                        <div>حجم فایل فلش: <span><?php echo e($device->flashSize); ?></span></div>
                                        <div>رمز: <span><?php echo e($device->password); ?></span></div>
                                        <div>تعداد کانال : <span><?php echo e($device->chanel); ?></span></div>
                                    </div>
                                    <div class="flash-img-cont">
                                        <div class="slider">
                                            <?php
                                                $imags = json_decode($device->imags);
                                            ?>
                                            <?php $__currentLoopData = $imags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="img-magnifier-container">
                                                    <img class="myimage" src="<?php echo e($img); ?>" alt="موردی یافت نشد" />
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <div class="next fa fa-right-long"></div>
                                            <div class="prev fa fa-left-long"></div>
                                        </div>
                                    </div>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <br>
                        <div>
                            جمع خرید :
                            <span style="color: red; font-weight: bold"><?php echo e($count); ?> هزار تومان </span>
                        </div>
                        <form action="<?php echo e(route('byFlash')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="total" value="<?php echo e($count); ?>">
                            <br>
                            <p>فایل های موجود در این سایت کاملا سالم هستند و در صورت نا کار آمد بودن فایل برای شما ، این وب
                                سایت
                                هیچ مسئولیتی را نمی پذیرد</p><br>
                            <b>موافقم </b><input class="check-after-by" type="checkbox"><br>
                            <br>
                            <b> استفاده از تخفیف </b> <input name="discount" type="checkbox"><br>
                            <input type="submit" disabled class="by-end" value="خرید نهایی">
                        </form>
                    <?php endif; ?>
                </section>
            </div>
            <div style="display: none" id="tab2" class="tab-content tab-content2">
                <section class="section2">
                    <ul>
                        <?php $__currentLoopData = $deviceByed; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deviceByed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $endTime = \Carbon\Carbon::parse($deviceByed->created_at)->add(5, 'day');
                                $timeForEnd = now()
                                    ->diff($endTime)
                                    ->format('%H:%I:%S-%Y-%M-%D');
                                $h = now()
                                    ->diff($endTime)
                                    ->format('%H');
                                $i = now()
                                    ->diff($endTime)
                                    ->format('%I');
                                $s = now()
                                    ->diff($endTime)
                                    ->format('%S');
                                $y = now()
                                    ->diff($endTime)
                                    ->format('%Y');
                                $m = now()
                                    ->diff($endTime)
                                    ->format('%M');
                                $d = now()
                                    ->diff($endTime)
                                    ->format('%D');
                            ?>
                            <div class="end-time">
                                <b>زمان باقی مانده برای دانلود فایل :</b><br><br>
                                <span><?php echo e($d); ?> روز</span> , <span><?php echo e($h); ?> ساعت</span> , <span
                                    id="i"><?php echo e($i); ?> </span>دقیقه , <span
                                    id="s"><?php echo e($s); ?></span> ثانیه
                            </div>
                            <li class="flash-cont">
                                <div class="flash-by-cont">
                                    
                                    <ul>
                                        <?php if($deviceByed->flash != 'false'): ?>
                                            <?php
                                                $linkFlashs = json_decode(\App\Models\device::find($deviceByed->deviceId)->flash);
                                                $flashId = \App\Models\device::find($deviceByed->deviceId)->id;
                                            ?>
                                            <li>دانلود فایل های فلش ارائه شده:<br><br>
                                                <?php $__currentLoopData = $linkFlashs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <a href="<?php echo e(route('downloadeFile', ['file' => $flashId, 'order' => $key, 'type' => 'flash'])); ?>"
                                                        class="link-download">دانلود فایل <?php echo e($key + 1); ?></a><br>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </li>
                                        <?php endif; ?>
                                        <br />
                                        <?php if($deviceByed->iprom != 'false'): ?>
                                            <?php
                                                $linkIprom = json_decode(\App\Models\device::find($deviceByed->deviceId)->iprom);
                                                $IpromId = \App\Models\device::find($deviceByed->deviceId)->id;
                                            ?>
                                            <li>دانلود فایل های ایپروم ارائه شده:<br><br>
                                                <?php $__currentLoopData = $linkIprom; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <a href="<?php echo e(route('downloadeFile', ['file' => $IpromId, 'order' => $key, 'type' => 'iprom'])); ?>"
                                                        class="link-download">دانلود فایل <?php echo e($key + 1); ?></a><br>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </li>
                                        <?php endif; ?>
                                    </ul>
                                </div>
                                <div class="flash-dis-cont">
                                    <?php
                                        $device = \App\Models\device::where('id', $deviceByed->deviceId)->first();
                                    ?>
                                    <div>آیدی سایت : <span><?php echo e($device->id2); ?></span></div>
                                    <div>کد روی برد : <span><?php echo e($device->name1); ?></span></div>
                                    <div>کد پشت برد : <span><?php echo e($device->name2); ?></span></div>
                                    <div>برچسب روی برد : <span><?php echo e($device->name3); ?></span></div>
                                    <div>پردازنده : <span><?php echo e($device->ic); ?></span></div>
                                    <div>لیبل: <span><?php echo e($device->lable); ?></span></div>
                                    <div>حجم فایل فلش: <span><?php echo e($device->flashSize); ?></span></div>
                                    <div>رمز: <span><?php echo e($device->password); ?></span></div>
                                    <div>تعداد کانال : <span><?php echo e($device->chanel); ?></span></div>
                                </div>
                                <div class="flash-img-cont">
                                    <div class="slider">
                                        <?php
                                            $imags = json_decode($device->imags);
                                        ?>
                                        <?php $__currentLoopData = $imags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="img-magnifier-container">
                                                <img class="myimage" src="<?php echo e($img); ?>" alt="" />
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <div class="next fa fa-right-long"></div>
                                        <div class="prev fa fa-left-long"></div>
                                    </div>
                                </div>
                            </li>
                            <br />
                            <?php
                                $commentBool = $commentBool = \App\Models\Comment::where('by_id', $deviceByed->id)->get();
                            ?>
                            <?php if($commentBool == '[]'): ?>
                                <form action="<?php echo e(route('addComment')); ?>" class="comment-form" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <label for="text">نظر خود رو درباره ی فایل بنویسید و به ازای هر نظر 5 هزار تومان تخفیف
                                        بگیرید</label><br><br>
                                    <textarea name="text" name="" id="" cols="30" rows="10"></textarea>
                                    <input name="device" type="hidden" value="<?php echo e($device->id); ?>"><br>
                                    <input name="by" type="hidden" value="<?php echo e($deviceByed->id); ?>"><br>
                                    <input class="sb-comment-form" type="submit" value="ثبت نظر">
                                </form><br>
                            <?php else: ?>
                                <p>از نظر شما ممنونیم تخفیف شما با موفقیت قرار داده شد</p>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </section>
            </div>
        </div>
        <!-- END tabs-content -->
    </div>
    <!-- END tabs -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <?php if(session('pay') == 'erroe'): ?>
        <script>
            alertEore('پرداخت نا موفق بود')
        </script>
    <?php endif; ?>
    <?php if(session('addComment') == 1): ?>
        <script>
            alertSucsses('از نظر شما ممنونم')
            $('#by-tab').parent().removeClass('active');
            $('#down-tab').parent().addClass('active');
            $('.tab-content1').hide();
            $('.tab-content2').show();
        </script>
    <?php endif; ?>
    <?php if(session('pay') == 'successful'): ?>
        <script !src="">
            alertSucsses('پرداخت موفق بود')
            $('#by-tab').parent().removeClass('active');
            $('#down-tab').parent().addClass('active');
            $('.tab-content1').hide();
            $('.tab-content2').show();
        </script>
    <?php else: ?>
        <script>
            // $("#tabs-nav li:first-child").addClass("active");
            // $(".tab-content").hide();
            // $(".tab-content:first").show();
        </script>
    <?php endif; ?>
    <script>
        setInterval(() => {
            var timz = document.getElementsByClassName('end-time');
            for (let j = 0; j < timz.length; j++) {
                //$(timz).find('#s').text();
                var s = eval($(timz[j]).find('#s').text());
                s = s - 1;
                if (s < 1) {
                    var i = eval($(timz[j]).find('#i').text());
                    if (i < 1) {
                        var h = eval($(timz[j]).find('#h').text());
                        h = h - 1;
                        s = 60
                        i = 60
                        $(timz[j]).find('#s').text(s)
                        $(timz[j]).find('#i').text(i)
                    }
                    i = i - 1;
                    s = 60
                    $(timz[j]).find('#s').text(s)
                    $(timz[j]).find('#i').text(i)
                }
                $(timz[j]).find('#s').text(s);
            }
        }, 1000);
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('flash.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\i\Documents\laravel\resources\views/flash/panel.blade.php ENDPATH**/ ?>